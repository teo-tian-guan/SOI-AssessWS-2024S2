/*© 2023, AvePoint, Inc. All rights reserved.*/

window.fetchUtility = function (options, errorFun) {
    var request = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
        },
        cache: 'no-store',
        body: options.data,
        credentials: "include",
        isParseJson: true,
        download: false
    };
    if (window.localStorage.getItem("CurrentRoleType") !== null) {
        request.headers["CurrentRoleType"] = window.localStorage.getItem("CurrentRoleType");
    }
    if (options.import) {
        options.headers = {
            "CurrentRoleType": request.headers.CurrentRoleType
        }
    }
    Object.assign(request, options);
    if (options.targetComponent) {
        var defaultUrlPrefix = CommonUtil.getTargetUrlPrefix(options.targetComponent);
        if (options.url.indexOf("/") == 0) {
            options.url = defaultUrlPrefix + options.url;
        }
        else {
            options.url = defaultUrlPrefix + "/" + options.url;
        }
    }
    if (request.method.toLowerCase() === "get") {
        request.body = null;
    }

    return fetch(options.url, request)
        .then(function (response) {
            if (response.ok) {
                if (request.download) {
                    return response;
                }
                else {
                    return response.text().then(function (dataString) {
                        return {
                            responseStatus: response.status,
                            responseString: dataString,
                            isParseJson: request.isParseJson,
                            isPassStatus: request.isPassStatus
                        };
                    });
                }
            } else {
                if (response.status == 403) {
                    window.location.href = "/error/" + response.status;
                } else if (response.status == 409) {
                    // for simulation
                    $$.loading(false);
                    $$.alert(true, { type: "w", content: I18N.getGUICommonValue("GC_Common_Error_403_Simulate_Content_Message") });
                    throw new Error("simulation");
                } else if (response.status == 401) {
                    response.json().then(function (result) {
                        if (result && result.status == 1001) {
                            let content =  I18N.getGUICommonValue('GC_Session_has_heen_Terminated_Message')
                            window.StudentPortal ? $$.messagebox({
                                title: I18N.getGUICommonValue('GC_Common_SessionAlertTitle_Entry'),
                                content: content,
                                width: 464,
                                classify: 'warn',
                                closable: false,
                                buttons: [{
                                    text: I18N.getGUICommonValue('GC_AUI_Messagebox_OK_Entry'), name: 'OK', onClick: () => {
                                        window.location.href = '/account/account/AADLogout';
                                    }, classify: 'theme'
                                }],
                            }) : $$.messagebox(true, {
                                type: 'w',
                                title: I18N.getGUICommonValue('GC_Common_SessionAlertTitle_Entry'),
                                content: content,
                                buttons: [{
                                    name: I18N.getGUICommonValue('GC_AUI_Messagebox_OK_Entry'), className: "button button-default", onClick: function () {
                                        window.location.href = '/account/account/AADLogout';
                                    }
                                }],
                            });
                        }
                        else {
                            window.location.href = SAComponentsUrl.URL_IDENTITYSERVER;
                        }
                    });
                } else {
                    if (errorFun) {
                        errorFun(response, response.headers.get('CustomErrorCode'));
                    }
                    else {

                        //$$.confirm
                        $$.alert(true, {
                            content: 'An error occurred while processing the request. Please try again later or contact the administrator for help.',
                            type: "i",
                            buttons: [
                                {
                                    name: "OK", className: "button button-theme", onClick: function () {
                                    }
                                },
                            ],
                        });

                        //throw new Error(response.statusText);
                    }
                }
            }
        }).then(function (fetchResult) {

            if (request.download) { return fetchResult };

            var queryResult = null;

            try {
                if (!fetchResult.responseString) {
                    return null;
                }
                if (fetchResult.isParseJson && fetchResult.responseString) {
                    //if ($.isEmptyObject(fetchResult.responseString)) {
                    //    queryResult = "";
                    //} else {
                    queryResult = JSON.parse(fetchResult.responseString);
                    if (fetchResult.isPassStatus) {
                        queryResult[FetchResponsePropName.status] = fetchResult.responseStatus;
                    }
                    //}
                } else {
                    queryResult = fetchResult.responseString;
                }
            } catch (ex) {
                $$.error("An error happened while fetching information. Error:", ex);
            }
            return queryResult;
        });
};