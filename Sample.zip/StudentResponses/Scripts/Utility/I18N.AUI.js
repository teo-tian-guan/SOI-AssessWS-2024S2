/*© 2023, AvePoint, Inc. All rights reserved.*/
AUI.setI18N = function () {
    return {
        button: {
            on: I18N.getGUICommonValue("GC_AUI_Button_On_Entry"),
            off: I18N.getGUICommonValue("GC_AUI_Button_Off_Entry")
        },
        calendar: {
            //选中的时间小于当前时间
            earlierTime: I18N.getGUICommonValue("GC_AUI_Calendar_EarlierTime_Message"),
            today: I18N.getGUICommonValue("GC_AUI_Calendar_Today_Entry"),
        },
        combobox: {
            //水印对应的词条
            waterMark: I18N.getGUICommonValue("GC_AUI_Combobox_WaterMark_Entry"),
            //过滤结果为空时的词条
            noMatches: I18N.getGUICommonValue("GC_AUI_Combobox_NoMatches_Message"),
            viewMore: I18N.getGUICommonValue("GC_AUI_Combobox_ViewMore_Message"),
            noItems: I18N.getGUICommonValue("GC_AUI_Combobox_NoItems_Message")
        },
        datagrid: {            
            noneMessage: I18N.getGUICommonValue("GC_AUI_Datagrid_noneMessage_Message"),
             more: I18N.getGUICommonValue("GC_AUI_Datagrid_More_Message"),
            less:I18N.getGUICommonValue("GC_AUI_Datagrid_Less_Message")
        },
        datepicker: {
            //选中的时间小于当前时间
            earlierTime: I18N.getGUICommonValue("GC_AUI_Datepicker_EarlierTime_Message"),
            today: I18N.getGUICommonValue("GC_AUI_Datepicker_Today_Entry"),
            timeZone: I18N.getGUICommonValue("GC_AUI_Datepicker_TimeZone_Entry"),
            savingTime: I18N.getGUICommonValue("GC_AUI_Datepicker_SavingTime_Message"),
            ok: I18N.getGUICommonValue("GC_AUI_Datepicker_Ok_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Datepicker_Cancel_Entry"),
            time: I18N.getGUICommonValue("GC_AUI_Datepicker_Time_Entry")
        },
        dialog: {
            close: I18N.getGUICommonValue("GC_AUI_Dialog_Close_Entry")
        },
        eventcalendar: {
            months: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_January_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_February_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_March_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_April_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_May_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_June_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_July_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_August_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_September_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_October_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_November_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_December_Entry")
            ],
            monthsShort: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Jan_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Feb_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Mar_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Apr_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_May_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Jun_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Jul_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Aug_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sep_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Oct_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Nov_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Dec_Short_Entry")
            ],
            days: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sunday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Monday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Tuesday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Wednesday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Thursday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Friday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Saturday_Entry")
            ],
            am: I18N.getGUICommonValue("GC_AUI_Gcalendar_AM_Entry"),
            pm: I18N.getGUICommonValue("GC_AUI_Gcalendar_PM_Entry"),
            more: I18N.getGUICommonValue("GC_AUI_EventCalendar_More_Entry"),
            less: I18N.getGUICommonValue("GC_AUI_EventCalendar_Less_Entry"),
            switchMonth: [I18N.getGUICommonValue("GC_AUI_EventCalendar_Previous_Entry"), I18N.getGUICommonValue("GC_AUI_EventCalendar_Next_Entry")]
        },
        gcalendar: {
            //采用12小时制时，上午的缩写
            am: I18N.getGUICommonValue("GC_AUI_Gcalendar_AM_Entry"),//"AM",
            //采用12小时制时，下午的缩写
            pm: I18N.getGUICommonValue("GC_AUI_Gcalendar_PM_Entry"),//"PM",
            //月份全称
            months: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_January_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_February_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_March_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_April_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_May_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_June_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_July_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_August_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_September_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_October_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_November_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_December_Entry")
            ], 
            shortCapitalMonths:
                [
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_JAN_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_FEB_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_MAR_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_APR_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_MAY_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_JUN_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_JUL_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_AUG_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_SEP_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_OCT_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_NOV_ShortCapital_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_DEC_ShortCapital_Entry")
                ],
            //月份简写
            shortMonths:
                [
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Jan_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Feb_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Mar_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Apr_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_May_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Jun_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Jul_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Aug_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Sep_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Oct_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Nov_Short_Entry"),
                    I18N.getGUICommonValue("GC_AUI_Gcalendar_Dec_Short_Entry")
                ],
            //星期全称
            weeks: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sunday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Monday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Tuesday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Wednesday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Thursday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Friday_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Saturday_Entry")
            ],
            //星期简写
            middleweeks: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sun_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Mon_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Tue_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Wed_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Thu_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Fri_Middle_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sat_Middle_Entry")
            ],
            //星期简写
            shortweeks: [
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sun_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Mon_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Tue_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Wed_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Thu_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Fri_Short_Entry"),
                I18N.getGUICommonValue("GC_AUI_Gcalendar_Sat_Short_Entry")
            ],
            //标题格式
            titleFormat: "m/, /yyyy",
            today: I18N.getGUICommonValue("GC_AUI_Calendar_Today_Entry")
        },
        math: {
            toolTip: I18N.getGUICommonValue("GC_AUI_Math_ToolTip_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Math_Title_Entry"),
            Arrows: I18N.getGUICommonValue("GC_AUI_Math_Arrows_Entry"),
            Basic: I18N.getGUICommonValue("GC_AUI_Math_Basic_Entry"),
            Cancel: I18N.getGUICommonValue("GC_AUI_Math_Cancel_Entry"),
            CannotRenderinMQ: I18N.getGUICommonValue("GC_AUI_Math_CannotRenderinMQ_Message"),
            CopyLaTeX: I18N.getGUICommonValue("GC_AUI_Math_CopyLaTeX_Entry"),
            Delimiters: I18N.getGUICommonValue("GC_AUI_Math_Delimiters_Entry"),
            Formulas: I18N.getGUICommonValue("GC_AUI_Math_Formulas_Entry"),
            Greek: I18N.getGUICommonValue("GC_AUI_Math_Greek_Entry"),
            Insert: I18N.getGUICommonValue("GC_AUI_Math_Insert_Entry"),
            InvalidFormula: I18N.getGUICommonValue("GC_AUI_Math_InvalidFormula_Entry"),
            Misc: I18N.getGUICommonValue("GC_AUI_Math_Misc_Entry"),
            Operators: I18N.getGUICommonValue("GC_AUI_Math_Operators_Entry"),
            Relationships: I18N.getGUICommonValue("GC_AUI_Math_Relationships_Entry"),
            SwitchtoAdvance: I18N.getGUICommonValue("GC_AUI_Math_SwitchtoAdvance_Entry"),
            SwitchtoBasic: I18N.getGUICommonValue("GC_AUI_Math_SwitchtoBasic_Entry"),
            TypesetFailed: I18N.getGUICommonValue("GC_AUI_Math_TypesetFailed_Entry"),
            Fraction: I18N.getGUICommonValue("GC_AUI_Math_Fraction_Entry"),
            Large: I18N.getGUICommonValue("GC_AUI_Math_Large_Entry"),
            Letterlike: I18N.getGUICommonValue("GC_AUI_Math_LetterLike_Entry"),
            Negated: I18N.getGUICommonValue("GC_AUI_Math_Negated_Entry"),
        },
        messagebox: {
            ok: I18N.getGUICommonValue("GC_AUI_Messagebox_OK_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Messagebox_Cancel_Entry"),
            close: I18N.getGUICommonValue("GC_AUI_Messagebox_Close_Entry")
        },
        multicombobox: {
            all: I18N.getGUICommonValue("GC_AUI_Multicombobox_All_Entry"),
            selectAllText: I18N.getGUICommonValue("GC_AUI_Multicombobox_SelectAllText_Entry"),
            //全选时显示的词条
            allText: I18N.getGUICommonValue("GC_AUI_Multicombobox_AllText_Entry"),            //
            none: I18N.getGUICommonValue("GC_AUI_Multicombobox_None_Entry"),
            selectedXItems: I18N.getGUICommonValue("GC_AUI_Multicombobox_SelectedXItems_Message"),
            selectedXItem: I18N.getGUICommonValue("GC_AUI_Multicombobox_SelectedXItem_Message"),
            //全选checkbox对应的词条
            selectAllCheckbox: I18N.getGUICommonValue("GC_AUI_Multicombobox_SelectAllCheckbox_Entry"),
            //column manager
            columns: I18N.getGUICommonValue("GC_AUI_Multicombobox_Columns_Entry"),
            ok: I18N.getGUICommonValue("GC_AUI_Multicombobox_Ok_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Multicombobox_Cancel_Entry"),
            placeholder: I18N.getGUICommonValue("GC_AUI_Multicombobox_Placeholder_Entry"),
            selectAllSearchResults: I18N.getGUICommonValue("GC_AUI_Multicombobox_SelectAllSearchResults_Entry")
        },
        pager: {
            showRows: I18N.getGUICommonValue("GC_AUI_Pager_ShowRows_Entry"),
            goTo: I18N.getGUICommonValue("GC_AUI_Pager_GoTo_Entry"),
            next: I18N.getGUICommonValue("GC_AUI_Pager_Next_Entry"),
            previous: I18N.getGUICommonValue("GC_AUI_Pager_Previous_Entry"),
            go: I18N.getGUICommonValue("GC_AUI_Pager_Go_Entry"),
            ofPageCount: I18N.getGUICommonValue("GC_AUI_Pager_OfPageCount_Entry"),
        },
        wizard: {
            stepMsg: I18N.getGUICommonValue("GC_AUI_Pager_Wizard_Message")
        },
        richcombobox: {
            empty: I18N.getGUICommonValue("GC_AUI_Richcombobox_Empty_Entry"),
            loading: I18N.getGUICommonValue("GC_AUI_Richcombobox_Loading_Entry"),
            viewMore: I18N.getGUICommonValue("GC_AUI_Richcombobox_ViewMore_Entry")
        },
        peoplepicker: {
            name: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Name_Entry"),
            userId: I18N.getGUICommonValue("GC_AUI_Peoplepicker_UserId_Entry"),
            staffId: I18N.getGUICommonValue("GC_AUI_Peoplepicker_StaffId_Entry"),
            email: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Email_Entry"),
            department: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Department_Entry"),
            searchBy: I18N.getGUICommonValue("GC_AUI_Peoplepicker_SearchBy_Entry"),
            searchResults: I18N.getGUICommonValue("GC_AUI_Peoplepicker_SearchResults_Entry"),
            doubleClick: I18N.getGUICommonValue("GC_AUI_Peoplepicker_DoubleClick_Entry"),
            selectedUser: I18N.getGUICommonValue("GC_AUI_Peoplepicker_SelectedUser_Entry"),
            add: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Add_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Cancel_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Title_Entry"),
            placeholders: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Placeholders_Entry"),
            placeholder: I18N.getGUICommonValue("GC_AUI_Peoplepicker_Placeholder_Entry")
        },
        uploader: {
            noFile: I18N.getGUICommonValue("GC_AUI_Uploader_NoFile_Entry"),
            changeFileMsg: I18N.getGUICommonValue("GC_AUI_Uploader_ChangeFile_Message"),
            notSupported: I18N.getGUICommonValue("GC_AUI_Uploader_NoSupported_Message"),
            gb: I18N.getGUICommonValue("GC_AUI_Uploader_GB_Entry"),
            mb: I18N.getGUICommonValue("GC_AUI_Uploader_MB_Entry"),
            kb: I18N.getGUICommonValue("GC_AUI_Uploader_KB_Entry"),
            ok: I18N.getGUICommonValue("GC_AUI_Uploader_OK_Entry"),
            b: I18N.getGUICommonValue("GC_AUI_Uploader_B_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Uploader_Cancel_Entry"),
            supportTypes: I18N.getGUICommonValue("GC_AUI_Uploader_SupportTypes_Entry"),
            removeFile: I18N.getGUICommonValue("GC_AUI_Uploader_RemoveFile_Entry"),
            exceedMaxFileSize: I18N.getGUICommonValue("GC_AUI_Uploader_ExceedMaxFileSize_Entry"),
            notZoreKB: I18N.getGUICommonValue("GC_AUI_Uploader_NotZoreKB_Entry"),
            deleteMessage: I18N.getGUICommonValue("GC_AUI_Uploader_Delete_Message"),
            uploadBtnText: I18N.getGUICommonValue("GC_AUI_Uploader_Button_Text_Entry"),
            moreText: I18N.getGUICommonValue("GC_AUI_Uploader_More_Text_Entry")
        },
        multicalendar: {
            allText: I18N.getGUICommonValue("GC_AUI_Multicalendar_AllText_Entry"),
            none: I18N.getGUICommonValue("GC_AUI_Multicalendar_None_Entry"),
            selectedXDates: I18N.getGUICommonValue("GC_AUI_Multicalendar_SelectedXDates_Entry"),
            selectedXDate: I18N.getGUICommonValue("GC_AUI_Multicalendar_SelectedXDate_Entry")
        },
        transferlist: {
            add: I18N.getGUICommonValue("GC_AUI_Transferlist_Add_Entry"),
            remove: I18N.getGUICommonValue("GC_AUI_Transferlist_Remove_Entry")
        },
        media: {
            upload: I18N.getGUICommonValue("GC_AUI_Media_Upload_Entry"),
            arrangeBy: I18N.getGUICommonValue("GC_AUI_Media_ArrangeBy_Entry"),
            webAddress: I18N.getGUICommonValue("GC_AUI_Media_WebAddress_Entry"),
            alternateText: I18N.getGUICommonValue("GC_AUI_Media_AlternateText_Entry"),
            text: I18N.getGUICommonValue("GC_AUI_Media_Text_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Media_Title_Entry"),
            width: I18N.getGUICommonValue("GC_AUI_Media_Width_Entry"),
            height: I18N.getGUICommonValue("GC_AUI_Media_Height_Entry"),
            name: I18N.getGUICommonValue("GC_AUI_Media_Name_Entry"),
            size: I18N.getGUICommonValue("GC_AUI_Media_Size_Entry"),
            uploadTime: I18N.getGUICommonValue("GC_AUI_Media_UploadTime_Entry"),
            emptyFolder: I18N.getGUICommonValue("GC_AUI_Media_EmptyFolder_Entry"),
            lock: I18N.getGUICommonValue("GC_AUI_Media_Lock_Entry"),
            altMessage: I18N.getGUICommonValue("GC_AUI_Media_AltMessage_Entry"),
            pictureTitle: I18N.getGUICommonValue("GC_AUI_Media_PictureTitle_Entry"),
            videoTitle: I18N.getGUICommonValue("GC_AUI_Media_VideoTitle_Entry"),
            fileTitle: I18N.getGUICommonValue("GC_AUI_Media_FileTitle_Entry"),
            audioTitle: I18N.getGUICommonValue("GC_AUI_Media_AudioTitle_Entry"),
            fileTip: I18N.getGUICommonValue("GC_AUI_Media_FileTip_Entry"),
            picTip: I18N.getGUICommonValue("GC_AUI_Media_PicTip_Entry"),
            audioTip: I18N.getGUICommonValue("GC_AUI_Media_AudioTip_Entry"),
            videoTip: I18N.getGUICommonValue("GC_AUI_Media_VideoTip_Entry"),
            unsupportedFile: I18N.getGUICommonValue("GC_AUI_Media_UnsupportedFile_Message"),
            deleteMessage: I18N.getGUICommonValue("GC_AUI_Media_DeleteMessage_Message"),
            adjustToA4Message: I18N.getGUICommonValue("GC_AUI_Media_AdjustToA4Message_Message"),
            imgNotExistMessage: I18N.getGUICommonValue("GC_AUI_Media_ImageNotExist_Message"),
            invalidMedia: I18N.getGUICommonValue("GC_AUI_Media_InvalidMedia_Message"),
            searchPlaceholder: I18N.getGUICommonValue("GC_AUI_Media_Search_Placeholder_Message")
        },
        music: {
            tooltip: I18N.getGUICommonValue("GC_AUI_Music_Tooltip_Entry"),
            header: I18N.getGUICommonValue("GC_AUI_Music_Header_Entry"),
            globalSetting: I18N.getGUICommonValue("GC_AUI_Music_GlobalSetting_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Music_Title_Entry"),
            defaultTitle: I18N.getGUICommonValue("GC_AUI_Music_DefaultTitle_Entry"),
            treble: I18N.getGUICommonValue("GC_AUI_Music_Treble_Entry"),
            bass: I18N.getGUICommonValue("GC_AUI_Music_Bass_Entry"),
            alto: I18N.getGUICommonValue("GC_AUI_Music_Alto_Entry"),
            tenor: I18N.getGUICommonValue("GC_AUI_Music_Tenor_Entry"),
            meter: I18N.getGUICommonValue("GC_AUI_Music_Meter_Entry"),
            key: I18N.getGUICommonValue("GC_AUI_Music_Key_Entry"),
            keyMode: I18N.getGUICommonValue("GC_AUI_Music_KeyMode_Entry"),
            keyMajor: I18N.getGUICommonValue("GC_AUI_Music_KeyMajor_Entry"),
            keyMinor: I18N.getGUICommonValue("GC_AUI_Music_KeyMinor_Entry"),
            clef: I18N.getGUICommonValue("GC_AUI_Music_Clef_Entry"),
            grandStave: I18N.getGUICommonValue("GC_AUI_Music_GrandStave_Entry"),
            ok: I18N.getGUICommonValue("GC_AUI_Music_Ok_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Music_Cancel_Entry"),
            grandToggleMessage: I18N.getGUICommonValue("GC_AUI_Music_GrandToggleMessage_Message"),
            tempo: I18N.getGUICommonValue("GC_AUI_Music_Tempo_Entry"),
            setTempo: I18N.getGUICommonValue("GC_AUI_Music_SetTempo_Entry"),
            setTempoAuto: I18N.getGUICommonValue("GC_AUI_Music_SetTempoAuto_Entry"),
            editorTitle: I18N.getGUICommonValue("GC_AUI_Music_EditorTitle_Entry"),
            notes: I18N.getGUICommonValue("GC_AUI_Music_Notes_Entry"),
            modeTitle: I18N.getGUICommonValue("GC_AUI_Music_ModeTitle_Entry"),
            insertMode: I18N.getGUICommonValue("GC_AUI_Music_InsertMode_Entry"),
            replaceMode: I18N.getGUICommonValue("GC_AUI_Music_ReplaceMode_Entry"),
            beamNote: I18N.getGUICommonValue("GC_AUI_Music_BeamNote_Entry"),
            dottedNote: I18N.getGUICommonValue("GC_AUI_Music_DottedNote_Entry"),
            doubleDottedNote: I18N.getGUICommonValue("GC_AUI_Music_DoubleDottedNote_Entry"),
            rests: I18N.getGUICommonValue("GC_AUI_Music_Rests_Entry"),
            pitches: I18N.getGUICommonValue("GC_AUI_Music_Pitches_Entry"),
            pitchUp: I18N.getGUICommonValue("GC_AUI_Music_PitchUp_Entry"),
            pitchDown: I18N.getGUICommonValue("GC_AUI_Music_PitchDown_Entry"),
            pitchUpOctave: I18N.getGUICommonValue("GC_AUI_Music_PitchUpOctave_Entry"),
            pitchDownOctave: I18N.getGUICommonValue("GC_AUI_Music_PitchDownOctave_Entry"),
            barlines: I18N.getGUICommonValue("GC_AUI_Music_Barlines_Entry"),
            normalBarline: I18N.getGUICommonValue("GC_AUI_Music_NormalBarline_Entry"),
            finalBarline: I18N.getGUICommonValue("GC_AUI_Music_FinalBarline_Entry"),
            doubleBarline: I18N.getGUICommonValue("GC_AUI_Music_DoubleBarline_Entry"),
            startRepeatBarline: I18N.getGUICommonValue("GC_AUI_Music_StartRepeatBarline_Entry"),
            endRepeatBarline: I18N.getGUICommonValue("GC_AUI_Music_EndRepeatBarline_Entry"),
            endStartRepeatBarline: I18N.getGUICommonValue("GC_AUI_Music_EndStartRepeatBarline_Entry"),
            grace: I18N.getGUICommonValue("GC_AUI_Music_Grace_Entry"),
            appoggiatura: I18N.getGUICommonValue("GC_AUI_Music_Appoggiatura_Entry"),
            acciaccatura: I18N.getGUICommonValue("GC_AUI_Music_Acciaccatura_Entry"),
            lines: I18N.getGUICommonValue("GC_AUI_Music_Lines_Entry"),
            intervalMessage: I18N.getGUICommonValue("GC_AUI_Music_IntervalMessage_Entry"),
            tieLine: I18N.getGUICommonValue("GC_AUI_Music_TieLine_Entry"),
            crescendoLine: I18N.getGUICommonValue("GC_AUI_Music_CrescendoLine_Entry"),
            diminuendoLine: I18N.getGUICommonValue("GC_AUI_Music_DiminuendoLine_Entry"),
            ornaments: I18N.getGUICommonValue("GC_AUI_Music_Ornaments_Entry"),
            fermata: I18N.getGUICommonValue("GC_AUI_Music_Fermata_Entry"),
            sforzato: I18N.getGUICommonValue("GC_AUI_Music_Sforzato_Entry"),
            staccato: I18N.getGUICommonValue("GC_AUI_Music_Staccato_Entry"),
            marcato: I18N.getGUICommonValue("GC_AUI_Music_Marcato_Entry"),
            tenuto: I18N.getGUICommonValue("GC_AUI_Music_Tenuto_Entry"),
            trill: I18N.getGUICommonValue("GC_AUI_Music_Trill_Entry"),
            turn: I18N.getGUICommonValue("GC_AUI_Music_Turn_Entry"),
            upperMordent: I18N.getGUICommonValue("GC_AUI_Music_UpperMordent_Entry"),
            lowerMordent: I18N.getGUICommonValue("GC_AUI_Music_LowerMordent_Entry"),
            accidentals: I18N.getGUICommonValue("GC_AUI_Music_Accidentals_Entry"),
            none: I18N.getGUICommonValue("GC_AUI_Music_None_Entry"),
            sharp: I18N.getGUICommonValue("GC_AUI_Music_Sharp_Entry"),
            flat: I18N.getGUICommonValue("GC_AUI_Music_Flat_Entry"),
            natural: I18N.getGUICommonValue("GC_AUI_Music_Natural_Entry"),
            doubleSharp: I18N.getGUICommonValue("GC_AUI_Music_DoubleSharp_Entry"),
            doubleFlat: I18N.getGUICommonValue("GC_AUI_Music_DoubleFlat_Entry"),
            dynamics: I18N.getGUICommonValue("GC_AUI_Music_Dynamics_Entry"),
            repeats: I18N.getGUICommonValue("GC_AUI_Music_Repeats_Entry"),
            segno: I18N.getGUICommonValue("GC_AUI_Music_Segno_Entry"),
            coda: I18N.getGUICommonValue("GC_AUI_Music_Coda_Entry"),
            fine: I18N.getGUICommonValue("GC_AUI_Music_Fine_Entry"),
            dcRepeat: I18N.getGUICommonValue("GC_AUI_Music_DcRepeat_Entry"),
            dsRepeat: I18N.getGUICommonValue("GC_AUI_Music_DsRepeat_Entry"),
            text: I18N.getGUICommonValue("GC_AUI_Music_Text_Entry"),
            textInputMessage: I18N.getGUICommonValue("GC_AUI_Music_TextInputMessage_Message"),
            textTop: I18N.getGUICommonValue("GC_AUI_Music_TextTop_Entry"),
            textBottom: I18N.getGUICommonValue("GC_AUI_Music_TextBottom_Entry"),
            textLeft: I18N.getGUICommonValue("GC_AUI_Music_TextLeft_Entry"),
            textRight: I18N.getGUICommonValue("GC_AUI_Music_TextRight_Entry"),
            actions: I18N.getGUICommonValue("GC_AUI_Music_Actions_Entry"),
            space: I18N.getGUICommonValue("GC_AUI_Music_Space_Entry"),
            enter: I18N.getGUICommonValue("GC_AUI_Music_Enter_Entry"),
            delete: I18N.getGUICommonValue("GC_AUI_Music_Delete_Entry"),
            grandMove_true: I18N.getGUICommonValue("GC_AUI_Music_GrandMove_true_Entry"),
            grandMove_false: I18N.getGUICommonValue("GC_AUI_Music_GrandMove_false_Entry"),
            beam: I18N.getGUICommonValue("GC_AUI_Music_Beam_Entry"),
            beam_start: I18N.getGUICommonValue("GC_AUI_Music_Beam_start_Entry"),
            beam_middle: I18N.getGUICommonValue("GC_AUI_Music_Beam_middle_Entry"),
            beam_end: I18N.getGUICommonValue("GC_AUI_Music_Beam_end_Entry"),
            beem_none: I18N.getGUICommonValue("GC_AUI_Music_Beem_none_Entry"),
            globalButton: I18N.getGUICommonValue("GC_AUI_Music_GlobalButton_Entry")
        },
        richeditor: {
            datepicker: I18N.getGUICommonValue("GC_AUI_Richeditor_Datepicker_Entry"),
            colorLegend: I18N.getGUICommonValue("GC_AUI_Richeditor_ColorLegend_Entry"),
            gdat: I18N.getGUICommonValue("GC_AUI_Richeditor_Gdat_Entry"),
            colorLegendTag: I18N.getGUICommonValue("GC_AUI_Richeditor_ColorlegendTag_Entry"),
            pictureTag: I18N.getGUICommonValue("GC_AUI_Richeditor_PictureTag_Entry"),
            audioTag: I18N.getGUICommonValue("GC_AUI_Richeditor_AudioTag_Entry"),
            videoTag: I18N.getGUICommonValue("GC_AUI_Richeditor_VideoTag_Entry"),
            tableTag: I18N.getGUICommonValue("GC_AUI_Richeditor_TableTag_Entry"),
            codeTag: I18N.getGUICommonValue("GC_AUI_Richeditor_CodeTag_Entry"),
            musicTag: I18N.getGUICommonValue("GC_AUI_Richeditor_MusicTag_Entry"),
            mathTag: I18N.getGUICommonValue("GC_AUI_Richeditor_MathTag_Entry"),
            resizeNote: I18N.getGUICommonValue("GC_AUI_Richeditor_Note_Resize_Message"),
			removeTableStyleMsg:I18N.getGUICommonValue("GC_AUI_Richeditor_RemoveTableStyle_Message")
        },
        tree: {
            searchForSchool: I18N.getGUICommonValue("GC_AUI_Tree_SearchForSchool_Entry"),
            searchForModule: I18N.getGUICommonValue("GC_AUI_Tree_SearchForModule_Entry"),
            refreshMessage: I18N.getGUICommonValue("GC_AUI_Tree_RefreshTitle_Entry"),
            leafNodeMessage: I18N.getGUICommonValue("GC_AUI_Tree_LeafNodeMessage_Message"),
            noneMessage: I18N.getGUICommonValue("GC_AUI_Tree_NoneMessage_Message")
        },
        colorlegend: {
            number: I18N.getGUICommonValue("GC_AUI_Colorlegend_Number_Entry"),
            description: I18N.getGUICommonValue("GC_AUI_Colorlegend_Description_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Colorlegend_Title_Entry"),
            alertMessage: I18N.getGUICommonValue("GC_AUI_ColorLegend_Alert_Message") ,
            fontSize: I18N.getGUICommonValue("GC_AUI_ColorLegend_FontSize_Message"),
            fontPosition: I18N.getGUICommonValue("GC_AUI_ColorLegend_FontPosition_Message"),
            borderColor: I18N.getGUICommonValue("GC_AUI_ColorLegend_BorderColor_Message"),
            defaultDirection: I18N.getGUICommonValue("GC_AUI_ColorLegend_DefaultDirection_Entry"),
            upDirection: I18N.getGUICommonValue("GC_AUI_ColorLegend_UpDirection_Entry"),
            downDirection: I18N.getGUICommonValue("GC_AUI_ColorLegend_DownDirection_Entry"),
            leftDirection: I18N.getGUICommonValue("GC_AUI_ColorLegend_LeftDirection_Entry"),
            rightDirection: I18N.getGUICommonValue("GC_AUI_ColorLegend_RightDirection_Entry")
        },
        fontlegend: {
            selectColor: I18N.getGUICommonValue("GC_AUI_Fontlegend_SelectColor_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_Folorlegend_Title_Entry"),
            number: I18N.getGUICommonValue("GC_AUI_Folorlegend_Number_Entry"),
            description: I18N.getGUICommonValue("GC_AUI_Folorlegend_Description_Entry"),
            delete: I18N.getGUICommonValue("GC_AUI_Folorlegend_Delete_Entry"),
            create: I18N.getGUICommonValue("GC_AUI_Folorlegend_Create_Entry")
        },
        gdat: {
            title: I18N.getGUICommonValue("GC_AUI_Gdat_Title_Entry")
        },
        comboboxshell: {
            ok: I18N.getGUICommonValue("GC_AUI_Comboboxshell_OK_Entry"),
            cancel: I18N.getGUICommonValue("GC_AUI_Comboboxshell_Cancel_Entry")
        },
        core: {
            routerPromptMessage: I18N.getGUICommonValue("GC_AUI_Core_RouterPrompt_Message")
        },
        filepreview: {
            download: I18N.getGUICommonValue("GC_AUI_FilePreview_Download_Entry"),
            close: I18N.getGUICommonValue("GC_AUI_FilePreview_Close_Entry"),
            title: I18N.getGUICommonValue("GC_AUI_FilePreview_Title_Entry"),
            htmlMessage: I18N.getGUICommonValue("GC_AUI_FilePreview_Html_Message"),
            htmlDownloadMessage: I18N.getGUICommonValue("GC_AUI_FilePreview_HtmlDownload_Message"),
            htmlLink: I18N.getGUICommonValue("GC_AUI_FilePreview_HtmlLink_Entry"),
            unknownMessage: I18N.getGUICommonValue("GC_AUI_FilePreview_Unknown_Message"),
            minAction: I18N.getGUICommonValue("GC_AUI_FilePreview_MinAction_Entry"),
            pageLimit: I18N.getGUICommonValue("GC_AUI_FilePreview_PageLimit_Message"),
            excelLimit: I18N.getGUICommonValue("GC_AUI_FilePreview_ExcelLimit_Message")
        },
        searchbox: {
            searchTitle: I18N.getGUICommonValue("GC_AUI_Searchbox_SearchTitle_Message"),
            searchIconTitle: I18N.getGUICommonValue("GC_AUI_Searchbox_SearchIconTitle_Message"),
            clearSearch: I18N.getGUICommonValue("GC_AUI_Searchbox_ClearSearch_Message")
        },
        imageviewer: {
            rotateCounterclosewise: I18N.getGUICommonValue("GC_AUI_Imageviewer_RotateCounterClosewise_Entry"),
            rotateClosewise: I18N.getGUICommonValue("GC_AUI_Imageviewer_RotateClosewise_Entry"),
            resetDefaultSize: I18N.getGUICommonValue("GC_AUI_Imageviewer_ResetDefaultSize_Entry"),
            zoomOut: I18N.getGUICommonValue("GC_AUI_Imageviewer_ZoomOut_Entry"),
            zoomIn: I18N.getGUICommonValue("GC_AUI_Imageviewer_ZoomIn_Entry"),
            delete: I18N.getGUICommonValue("GC_AUI_Imageviewer_Delete_Entry")
        }
    };

}