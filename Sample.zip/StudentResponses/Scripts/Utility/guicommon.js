/*© 2023, AvePoint, Inc. All rights reserved.*/
window.CommonUtil = {};

window.CommonUtil.Simulate = function (userId, errorHandler) {

    if (!CommonUtil.isSimulated() && userId) {
        $$.loading(true);
        var options = {
            targetComponent: SAComponents.COMPONNET_IDENTITY,
            url: "account/simulate",
            method: "POST",
            data: JSON.stringify({ userid: userId, returnUrl: window.location.href })
        };
        fetchUtility(options).then(function (result) {
            if (result.status == 203) {
                $$.loading(false);
                console.log("no permission to  simulate");
                errorHandler()
            }
            else
                if (result.status != 100) {
                    $$.loading(false);
                    console.log("simulate failed");
                    errorHandler();
                }
                else {
                    window.location = '/';
                }
            console.log(result);
        });
    }
}

window.CommonUtil.CancelSimulate = function () {

    if (!CommonUtil.isSimulated()) {
        return;
    }

    $$.loading(true);
    var options = {
        targetComponent: SAComponents.COMPONNET_IDENTITY,
        url: "account/simulate",
        method: "POST",
        data: JSON.stringify({ userid: CommonUtil.OrginalUser(), returnUrl: window.location.href })
    };
    fetchUtility(options).then(function (result) {
        if (result.status != 100) {
            throw "cancel simulate failed";
        }
        else {
            var returnUrl = result.returnUrl;
            if (!returnUrl) {
                returnUrl = '/';
            }

            window.CommonUtil.RemoveLocalSimulateInfo();
            window.location = returnUrl;
        }
        console.log(result);
    });
}

window.CommonUtil.isSimulated = function () {
    return window.simulated;
}

window.CommonUtil.OrginalUser = function () {
    return window.orinalUser;
}

window.CommonUtil.RemoveLocalSimulateInfo = function () {
    window.simulated = false;
    window.orinalUser = '';
}
window.CommonUtil.RemoveSessionSimulateInfo = function () {
    window.simulated = false;
    window.orinalUser = '';
}

window.CommonUtil.updatePageTitle = function (title) {
    if (typeof title != "undefined") {
        document.title = title;
    }
}

window.CommonUtil.isEmptyCSharpDate = function (date) {
    if (date.match('0001-01-01T')) {
        return true;
    } else {
        return false;
    }
}

/**
 * @param {Date} date 需要转换的Date
 * @param {Boolean}hasTime 是否显示时间
 * @param {String} format 转换格式
 * 注意：区分大小写
 * y:表示年[yyyy,yy],说明：yyyy表示四位数字的年,如:1996,yy表示两位数字的年,如:61。
 * M:表示年中的月份[M,MM,MMM],说明：MM如果月份不足两位前方补零，MMM 表示月份的英文字母缩写。
 * d:月份中的天数[d,dd]。
 * h:一天中的小时数[h,hh]。
 * m:小时中的分钟数[m,mm]。
 * s:分钟中的秒数[s,ss]。
 * tt :PM|AM。
 */
window.CommonUtil.formatDateTime = function (date, hasTime, format, hasSecond) {
    if (hasTime == null) {
        hasTime = true;
    }
    if (typeof date === "string") {
        if (CommonUtil.isEmptyCSharpDate(date)) {
            return "";
        }
        date = new Date(date);//new Date(date.replace("T", " ").replace(/-/g, "/"));
    }
    /* format 等于true时,返回Date类型的数据*/
    if (format === true) {
        return new Date(date);
    }
    if (hasSecond) {
        format = SADefaultFormat.DATE + (hasTime ? ' ' + SADefaultFormat.TIME + ':ss' : '');
    }
    /*可以设置默认的format*/
    if (!format) {
        format = SADefaultFormat.DATE + (hasTime ? ' ' + SADefaultFormat.TIME : '');
    }
    var dateStr = $$.gcalendar('toFormatString', { date: date, format: format.replace(/[y]{2}/g, 'y') });
    return dateStr;
};

window.CommonUtil.getTargetUrlPrefix = function (targetComponent) {
    var defaultUrlPrefix = "";
    switch (targetComponent) {
        case SAComponents.COMPONENT_ADMINISTRATION: defaultUrlPrefix = SAComponentsUrl.URL_ADMINISTRATION; break;
        case SAComponents.COMPONENT_ASSESSMENTSCHEDULE: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTSCHEDULE; break;
        case SAComponents.COMPONENT_ASSESSMENTAUTHORING: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTAUTHORING; break;
        case SAComponents.COMPONENT_ASSESSMENTPRINTINGTRACKING: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTPRINTING; break;
        case SAComponents.COMPONENT_ASSESSMENTTAKING: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTTAKING; break;
        case SAComponents.COMPONENT_ASSESSMENTMARKING: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTMARKING; break;
        case SAComponents.COMPONENT_ASSESSMENTREPORTING: defaultUrlPrefix = SAComponentsUrl.URL_ASSESSMENTREPORTING; break;
        case SAComponents.COMPONENT_GUICOMMON: defaultUrlPrefix = SAComponentsUrl.URL_GUICOMMON; break;
        case SAComponents.COMPONENT_DATABASESETUP: defaultUrlPrefix = SAComponentsUrl.URL_DATABASESETUP; break;
        case SAComponents.COMPONENT_LCMS: defaultUrlPrefix = SAComponentsUrl.URL_LCMS; break;
        case SAComponents.COMPONNET_IDENTITY: defaultUrlPrefix = SAComponentsUrl.URL_IDENTITYSERVER; break;
    }
    return defaultUrlPrefix;
};

window.promiseAll = function () {
    return Promise.all(Array.prototype.slice.call(arguments))
        .catch(function (message) {
            $$.info(message);
        });
};
/**
 * 获取Url参数值
 */
window.CommonUtil.getQueryString = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURIComponent(r[2]); return null;
};


/**
 * 更新QueryString, if value is empty,remove it;If param exists already, update it
 * @param {String} key queryString key
 * @param {String} value queryString value
 * @param {String} queryString old queryString [可以不传，不传读location]
 * @return {String} QueryString New queryString
 */
function updateQueryStringParam(key, value, queryString) {
    var urlQueryString = queryString || document.location.search,
        newParam = key + '=' + value,
        params = newParam;

    /*If the "search" string exists, then build params from it*/
    if (urlQueryString) {
        var updateRegex = new RegExp('([\?&])' + key + '[^&]*');
        var removeRegex = new RegExp('([\?&])' + key + '=[^&;]+[&;]?');

        if (typeof value == 'undefined' || value == null || value == '') {
            /* Remove param if value is empty*/
            params = urlQueryString.replace(removeRegex, "$1");
            params = params.replace(/[&;]$/, "");

        } else if (urlQueryString.match(updateRegex) !== null) {
            /* If param exists already, update it*/
            params = urlQueryString.replace(updateRegex, "$1" + newParam);

        } else { /*Otherwise, add it to end of query string*/
            params = urlQueryString + '&' + newParam;
        }
    }

    // no parameter was set so we don't need the question mark
    params = params == '?' ? '' : params;
    return params;
}

/**
 * 更新React parameter：if value is empty,remove it;If param exists already, update it
 * @param {Object} data 需要更新的数据源
 * @param {String} urlQueryString old queryString
 * @return {String} params :返回React params 
 */
function updateReactQueryStringParam(data, urlQueryString) {
    var params = '',
        queryObject = {},
        queryArray = [];
    if (urlQueryString != undefined) {
        queryArray = urlQueryString.split('/');
        queryArray.splice(0, 1);
        for (var i = 0, icount = queryArray.length; i < icount; i++) {
            if (i % 2 == 0) {
                queryObject[queryArray[i]] = queryArray[i + 1];
            }
        }
        var tempQuery = {};
        $.extend(tempQuery, queryObject, data);
        for (var key in tempQuery) {
            if (tempQuery.hasOwnProperty(key)) {
                var value = tempQuery[key];
                if (tempQuery.hasOwnProperty(key) === true) {
                    if (typeof value == 'undefined' || value == null || value == '') {
                        continue;
                    }
                    params += '/' + key + '/' + value;
                }
            }
        }
    }
    return params;
}

/**
 * 设置QueryString，默认设置React Router Parameter
 * @param {Object} data 需要设置的Parameter
 * @param {String} rootPath React rootPath
 * @param {Boolean} isNoneReactFormat 是否为ReactFormat[该值可以不传，当不传或值为false,表示设置React parameter,值为true时，设置]
 * @return {String} url 
 */
window.CommonUtil.setQueryString = function (data, rootPath, isNoneReactFormat) {
    rootPath = rootPath || '';
    var baseUrl = '',
        params = "";
    if (typeof (data) != 'object') {
        $$.warn('data must be Object');
        return;
    }
    baseUrl = [location.protocol, '//', location.host, rootPath].join('');
    if (isNoneReactFormat) {
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                params = updateQueryStringParam(key, data[key], params);
                params = params.indexOf('?') != -1 ? params : '?' + params;
            }
        }
    } else {
        if (!rootPath) {
            $$.warn('please input parameter : rootpath');
            return;
        }
        params = updateReactQueryStringParam(data, '');
    }
    return baseUrl + params;
};

function setCookie(name, value) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
}

/**
 * 获取Redirect Url，并设置url parameter
 * @param {String} component 
 * @param {String} path 
 * @param {String} json 需要设置的Parameter[JSON]
 * @param {Boolean} isSaveInSession 是否存储到sessionStorage中
 */
window.CommonUtil.getRedirectUrl = function (component, path, json, isSaveInCookie) {
    path = '/' + path;
    if (json) {
        var params = "";
        /* TODO Clear */
        var data = JSON.parse(json);
        for (var key in data) {
            if (isSaveInCookie) {
                setCookie(key, data[key]);
            }
            params = updateQueryStringParam(key, data[key], params);
        }
        path += params.indexOf('?') != -1 ? params : '?' + params;
    }

    return window.location.protocol + "//" + window.location.host + component + path;
};

/**
 * Replace Url,并设置url parameter
 * @param {String} component
 * @param {String} path
 * @param {String} json
 * @param {Boolean} isSaveInSession
 */
window.CommonUtil.replaceUrl = function (component, path, json, isSaveInCookie) {
    var url = window.CommonUtil.getRedirectUrl(component, path, json, isSaveInCookie);
    window.location.replace(url);
};

window.CommonUtil.redirectToUrl = function (component, path, json, isSaveInCookie) {
    var url = window.CommonUtil.getRedirectUrl(component, path, json, isSaveInCookie);
    window.location.href = url;
};

window.CommonUtil.openURLForAdmin = function (url, isReplaceCurrentPagee) {
    var redirectUrl = url;
    if ($.isEmptyObject(GuiCommonComponetUrl)) {
        redirectUrl = SAComponentsUrl.GuiCommonComponetUrl + url;
    } else {
        redirectUrl = url;
    }
    if (isReplaceCurrentPagee) {
        window.location.href = redirectUrl;
    } else {
        window.open(redirectUrl);
    }
}

var encryptKey = [201, 219, 55, 183, 156, 64, 85, 204, 201, 219, 55, 183, 156, 64, 85, 204];
window.CommonUtil.encryptValue = function (value) {
    return value = ajs.CspCrossPlatformExchangeWrapper.WrapKey(value, encryptKey);
};

window.CommonUtil.generatGuid = function () {
    var s = [], i = 0,
        hexDigits = "0123456789abcdef";
    for (; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
    s[8] = s[13] = s[18] = s[23] = "-";
    var newGuid = s.join("");
    return newGuid;
};

window.CommonUtil.convertFileSize = function (byteLength) {
    return $$.convertFileSize(byteLength);
};

window.userProfileManager = {};

userProfileManager.currentUser = function () {
    var user = {};
    if (userProfile) {
        user = {
            id: userProfile.id,
            name: userProfile.name,
            displayName: userProfile.DisplayName,
            userType: userProfile.UserType
        };
    }
    return user;
}

userProfileManager.getAccessToken = function () {
    return typeof (userInfo) != "undefined" ? userInfo.access_token : null;
}

userProfileManager.setAccessToken = function (token) {
    if (typeof window.userInfo !== "object") window.userInfo = {};
    userInfo.access_token = token;
}

Date.prototype.format = function (format) {
    var o = {
        "M+": this.getMonth() + 1, //month
        "d+": this.getDate(),    //day
        "h+": this.getHours(),   //hour
        "m+": this.getMinutes(), //minute
        "s+": this.getSeconds(), //second
        "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
        "S": this.getMilliseconds() //millisecond
    }
    if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
        (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(format))
        format = format.replace(RegExp.$1,
            RegExp.$1.length == 1 ? o[k] :
                ("00" + o[k]).substr(("" + o[k]).length));
    return format;
}

window.CommonUtil.sessionTimeoutTime = 1000 * 60 * 30;

window.CommonUtil.StayInSession = function () {
    let url = GuiCommonComponetUrl + "/api/common/InitSetting";
    fetch(url).then(function (response) {
        if (response.status !== 200) {
            return;
        }
        response.json().then(function (initSetting) {
            if (initSetting && initSetting.sessionTimeout && initSetting.sessionTimeout != 0) {
                window.CommonUtil.sessionTimeoutTime = initSetting.sessionTimeout;
            }
            window.CommonUtil.singleSessionLogon = initSetting.singleSessionLogon;
        });
    });
}

window.CommonUtil.RefreshTimeout = function (customTimeout) {
    window.CommonUtil.StayInSession()
}

window.CommonUtil.ShowInvigilatorAssignmentLoading = function (isLoading) {
    if (isLoading) {
        window.InvigilatorAssignmentLoadingCount++;
        $$.loading(true);
    } else {
        if (window.InvigilatorAssignmentLoadingCount - 1 > 0) {
            window.InvigilatorAssignmentLoadingCount--;
        } else {
            window.InvigilatorAssignmentLoadingCount = 0;
            $$.loading(false);
        }
    }
}

window.CommonUtil.toFocusChildNode = function (elements) {
    // e.g.
    // elements = [
    //     '.common-content .****',
    //     '.common-content',
    // ];
    let focusEle = null;
    for (let item of elements) {
        let focusable = $(item).find(':focusable:visible:not(:disabled):not([aria-disabled="true"]):not([tabindex="-1"])');
        if (focusable.length > 0) {
            focusEle = focusable[0];
            break;
        }
    }
    //focusEle && focusEle.focus();
    focusEle ? focusEle.focus() : document.activeElement.blur();
}