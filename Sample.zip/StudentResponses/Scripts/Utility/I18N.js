/*© 2023, AvePoint, Inc. All rights reserved.*/
(function (window) {
    "use strict";

    window.AveUI = window.AveUI || {};

    var I18NMap = function () { };
    I18NMap.prototype = {
        _length: 0,
        _DEF_PERFIX: '_MAP_KEY_',
        size: function () {
            return this._length;
        },
        get: function (key) {
            return this[this._DEF_PERFIX + key];
        },
        put: function (key, value) {
            if (!this[this._DEF_PERFIX + key]) {
                this._length++;
            }
            this[this._DEF_PERFIX + key] = value;
            return value;
        },
        remove: function (key) {
            if (this._length > 0 && this[this._DEF_PERFIX + key]) {
                delete this[this._DEF_PERFIX + key];
                this._length--;
                return true;
            }
            return false;
        },
        getKeySet: function () {
            var retArr = [];
            for (var key in this) {
                if (key.length > this._DEF_PERFIX.length && key.indexOf(this._DEF_PERFIX) === 0) {
                    retArr.push(key.substr(this._DEF_PERFIX.length));
                }
            }
            return retArr;
        }
    };

    String.prototype.format = function () {
        var args = arguments;
        var bool = Object.prototype.toString.call(args[0]) === '[object Array]';
        return this.replace(/\{(\d+)\}/g, function (m, n) {
            return bool ? args[0][n] : args[n];
        });
    };

    var createNamespace = function () {
        var arg = arguments, o = null, i, j, d;
        for (i = 0; i < arg.length; i = i + 1) {
            d = arg[i].split(".");
            o = window.AveUI;
            j = d[0] === "AveUI" ? 1 : 0;
            for (; j < d.length; j = j + 1) {
                o[d[j]] = o[d[j]] || {};
                o = o[d[j]];
            }
        }
        return o;
    };
    var namespaceFormatString = function (namespace) {
        var nm;
        if (namespace.split(".")[0] === "AveUI") {
            nm = namespace.replace(/\./g, "_");
        } else {
            nm = "AveUI" + namespace.replace(/\./g, "_");
        }
        return nm;
    };

    window.I18N = window.I18N || {
        /*
		 * @method I18N.get(namespace, key, args)
		 * @param  namespace (string)
		 * @param key (string)
		 * @param args (string)
		 */
        get: function (component, args) {
            var key = args[0],
                parameters = Array.prototype.slice.call(args, 1),
                val = __I18NMap__.get(namespaceFormatString(component) + key);
            if (val === undefined) {
                val = __DefaultI18NMap__.get(namespaceFormatString(component) + key);
            }
            return val === undefined ? args[1] : parameters.length > 0 ? val.format(parameters) : val;
        },
        getAdministrationValue: function () {
            return this.get(SAComponents.COMPONENT_ADMINISTRATION, arguments);
        },
        getAuthoringValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTAUTHORING, arguments);
        },
        getPrintingValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTPRINTINGTRACKING, arguments);
        },
        getMarkingValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTMARKING, arguments);
        },
        getScheduleValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTSCHEDULE, arguments);
        },
        getTakingValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTTAKING, arguments);
        },
        getFeatureCommonValue: function () {
            return this.get(SAComponents.COMPONENT_FEATURECOMMON, arguments);
        },
        getGUICommonValue: function () {
            return this.get(SAComponents.COMPONENT_GUICOMMON, arguments);
        },
        getReportingValue: function () {
            return this.get(SAComponents.COMPONENT_ASSESSMENTREPORTING, arguments);
        },
        getDatabaseValue: function () {
            return this.get(SAComponents.COMPONENT_DATABASESETUP, arguments);
        },
        getMsg: function () {
            var args = arguments,
                val = __I18NMap__.get(namespaceFormatString(args[0]) + args[1]);
            if (val === undefined) {
                val = __DefaultI18NMap__.get(namespaceFormatString(args[0]) + args[1]);
            }
            return val === undefined ? "" : val;
        }
    };

    window.__DefaultI18NMap__ = window.__DefaultI18NMap__ || new I18NMap();
    window.__I18NMap__ = window.__I18NMap__ || new I18NMap();

    var languageCallback = function (namespace, requestText) {
        try {
            var nm = namespaceFormatString(namespace),
                requestI18NObject = null;
            if (typeof requestText === "object") {
                requestI18NObject = requestText;
            }
            else if (typeof requestText === "string") {
                requestI18NObject = $.parseJSON(requestText);
            }
            if (requestI18NObject !== null) {
                for (var key in requestI18NObject) {
                    if (requestI18NObject.hasOwnProperty(key)) {
                        __DefaultI18NMap__.put(nm + key, requestI18NObject[key]);
                    }
                }
            }
        }
        catch (excep) {
            $$.error("An error occured while analyzing I18N file. Component:" + namespace + ". " + excep);
        }
    };

    /*
     * 注册导入相关的资源文件, url相对路径
     * @method I18N.register(namespace, url)
     * @param  namespace (string)
     * @param  url (string)
     */
    I18N.register = function (namespace, url, lang) {
        try {
            createNamespace(namespace);
            //getDefaultLanguage(namespace, url);
            var langName = lang === undefined ? SADefaultFormat.LANGUAGE : "." + lang,
                newurl = CommonUtil.getTargetUrlPrefix(namespace) + "/resources" + url + langName + ".js";
            $.ajax({
                url: newurl,
                success: function (requestText) {
                    languageCallback(namespace, requestText);
                },
                error: function (httpRequest, textStatus, errorThrown) {
                    $$.error("An error occured while registering I18N file. Component:" + namespace + ", url:" + url + ". " + errorThrown.message);
                },
                async: false,
                contentType: 'application/json;charset=UTF-8',
                dataType: "json"
            });
        }
        catch (excep) {
            $$.error("An error occured while registering I18N file. Component:" + namespace + ", url:" + url + ". " + excep);
        }
    };
})(window);
