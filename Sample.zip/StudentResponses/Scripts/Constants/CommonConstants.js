/*© 2023, AvePoint, Inc. All rights reserved.*/
window.AveAuthenticationTypes = {
    LocalSystem: 0,
    ADIntegration: 1
};

window.FetchStatus = {
    None: 0,
    Begin: 1,
    End: 2
};

window.FetchResponsePropName = {
    status: "GResponseStatus"
}

window.SADefaultFormat = {
    DATE: "dd MMM yyyy (DDD)",
    TIME: "hh:mm",
    DATETIME: "dd MMM yyyy (DDD) hh:mm",
    LANGUAGE: ""
};

window.SANavigationConstant = {
    NAVIGATION_ADMINISTRATION: "/admin",
    NAVIGATION_ASSESSMENTAUTHORING: "/authoring",
    NAVIGATION_ASSESSMENTPRINTINGTRACKING: "/printingandtracking",
    NAVIGATION_ASSESSMENTMARKING: "/marking",
    NAVIGATION_ASSESSMENTSCHEDULE: "/schedule",
    NAVIGATION_ASSESSMENTTAKING: "/taking",
    NAVIGATION_GUICOMMON: "/",
    NAVIGATION_ASSESSMENTREPORTING: "/reporting",
    NAVIGATION_PRINTING: '/',
    NAVIGATION_LCMS: '/storage',
    NAVIGATION_ARCHIVE: "/admin/archives",
    NAVIGATION_ADMINISTRATION_SPECIALNEEDSSTUDENTS: '/admin/specialneedstudent'
};

window.SAComponents = {
    COMPONENT_ADMINISTRATION: "Administration",
    COMPONENT_ASSESSMENTAUTHORING: "AssessmentAuthoring",
    COMPONENT_ASSESSMENTPRINTINGTRACKING: "AssessmentPrintingTracking",
    COMPONENT_ASSESSMENTMARKING: "AssessmentMarking",
    COMPONENT_ASSESSMENTSCHEDULE: "AssessmentSchedule",
    COMPONENT_ASSESSMENTTAKING: "AssessmentTaking",
    COMPONENT_FEATURECOMMON: "FeatureCommon",
    COMPONENT_GUICOMMON: "GuiCommon",
    COMPONENT_ASSESSMENTREPORTING: "AssessmentReporting",
    COMPONENT_DATABASESETUP: "DatabaseSetup",
    COMPONENT_LCMS: "Storage",
    COMPONNET_IDENTITY: "Identity"
};

window.SAComponentsUrl = {
    URL_ADMINISTRATION: "http://localhost:12500",
    URL_ASSESSMENTSCHEDULE: "http://localhost:12501",
    URL_ASSESSMENTAUTHORING: "http://localhost:12502",
    URL_ASSESSMENTTAKING: "http://localhost:12503",
    URL_ASSESSMENTMARKING: "http://localhost:12504",
    URL_ASSESSMENTREPORTING: "http://localhost:12505",
    URL_GUICOMMON: "http://localhost:12506",
    URL_DATABASESETUP: "http://localhost:12507",
    URL_IDENTITYSERVER: "http://localhost:12508",
    URL_ASSESSMENTPRINTING: "http://localhost:12511",
    URL_LCMS: "http://localhost:25311",
};
window.SAOrderByEnum = {
    ASC: 0,
    DESC: 1
};
window.SAConstants = {
    CACHE_SA_LANGUAGE: "SALanguage",
    CACHE_SA_DATE_PATTERN: "SADatePattern",
    CACHE_SA_TIME_PATTERN: "SATimePattern"
};

window.SAPeoplePickerItemType = {
    Student: 0,
    Staff: 1,
    ADGroup: 2,
    CustomGroup: 3
};

window.ClientConstants = {
    GUICOMMON: "GuiCommon"
};

window.ApiResourceConstants = {
    AUTHORINGAPI: "authoringAPI",
    MARKINGAPI: "markingAPI",
    REPORTAPI: "reportingAPI",
    SCHEDULEAPI: "schedulingAPI",
    ADMINISTRATIONAPI: "adminAPI",
    TAKINGAPI: "takingAPI",
    GUICOMMONAPI: "commonAPI",
    TIMERAPI: "timerAPI",
    LCMSAPI: "lcmsAPI",
    IDENTITYAPI: "IdentityApi",
};

window.authScope = [
    "openid",
    "profile",

    ApiResourceConstants.ADMINISTRATIONAPI,
    ApiResourceConstants.AUTHORINGAPI,
    ApiResourceConstants.MARKINGAPI,
    ApiResourceConstants.REPORTAPI,
    ApiResourceConstants.SCHEDULEAPI,
    ApiResourceConstants.TAKINGAPI,
    ApiResourceConstants.GUICOMMONAPI,
    ApiResourceConstants.TIMERAPI,
    ApiResourceConstants.LCMSAPI,
    ApiResourceConstants.IDENTITYAPI
];
window.InvigilatorAssignmentLoadingCount = 0;

window.SAPreviewFileTypes = {
    IMAGE_VIEWER: ["bmp", "png", "jpg", "gif"],
    AUDIO_VIEWER: ["m4a", "mp3", "wav"],
    VIDEO_VIEWER: ["m4v", "mp4"],
    WEB_VIEWER: ["htm", "html", "xml", "xhtml"],
    TEXT_VIEWER: ["css", "java", "js", "log", "mht", "mhtm", "mhtml", "php", "py", "txt"],
    DOCUMENT_VIEWER: ["doc", "docx", "docm", "xls", "xlsx", "xlsm", "ppt", "pptx", "pptm", "csv", "rtf", "pdf"],
    DOCUMENT_VIEWER_EXTENSION: {
        WORD: ["doc", "docx", "docm", "rtf"],
        EXCEL: ["xls", "xlsx", "xlsm", "csv"],
        PPT: ["ppt", "pptx", "pptm"],
        PDF: ["pdf"]
    }
};

window.StudentUserGuidEnum = {
    SA20WebSubmitResponsesForDeliverableOfFileSubmission: -12,                                //SA 2.0 Web – Submit Responses for Deliverable of File Submission
    SA20WebSubmitResponsesForDeliverableOfEssayAndReflectionJournal: -13,                     //SA 2.0 Web – Submit Responses for Deliverable of Essay and Reflection Journal
    SA20WebSubmitResponsesForDeliverableOfSelfEvaluation: -14,                                //SA 2.0 Web – Submit Responses for Deliverable of Self Evaluation
	SA20WebSubmitResponsesForDeliverableOfPeerEvaluation: -15,                                //SA 2.0 Web – Submit Responses for Deliverable of Peer Evaluation
};

window.StudentUserGuidMaping =
    [{
        relationUrl: ["/account"],
        value: 4
    },
    {
        relationUrl: ["/common", "/"],
        value: 5
    },
    {
        relationUrl: ["/admin/AssessmentPaperRepository/Student"],
        value: 6
    },
    {
        relationUrl: ["/admin/MyAnnouncement/AnnouncementDetail"],
        value: 7
    },
    {
        relationUrl: ["/admin/MyAnnouncement"],
        value: 8
    },
    {
        relationUrl: ["/admin/managelinks"],
        value: 16
    },
    {
        relationUrl: ["/admin/mycalendar"],
        value: 19
    },
    {
        relationUrl: ["/marking/Student/studentassessmentgrades"],
        value: 20
    },
    {
        relationUrl: ["/marking/Student/assessmentresult"],
        value: 21
    },
    {
        relationUrl: ["/admin/AssessmentPaperRepository/Student/AllAssessmentRepository"],
        value: 22
    },
    {
        relationUrl: ["admin/AssessmentPaperRepository/Student/PaperQuestions"],
        value: 23
    },
    {
        relationUrl: ["/reporting"],
        value: 24
    },
    {
        relationUrl: ["/admin/Archives"],
        value: 25
    }];

window.StaffUserGuideMapping = {
    //此部分为common组件介绍部分，忽略不用添加
    RepublicPolytechnicSA20StaffUserGuidev: 1,                                //Republic Polytechnic SA 2.0 Staff User Guide v2.0
    StaffUserGuideVersion: 2,                                                 //Staff User Guide Version 2.0
    Login: 3,                                                                 //1 Login
    OverallProcessFlow: 4,                                                    //1.1 Overall Process Flow
    CommonFeatures: 5,                                                        //2 Common Features
    Filter: 6,                                                                //2.1 Filter
    Search: 7,                                                                //2.2 Search
    Export: 8,                                                                //2.3 Export
    Import: 9,                                                                //2.4 Import
    ManageTableColumns: 10,                                                    //2.5 Manage Table Columns
    SortTableColumns: 11,                                                      //2.6 Sort Table Columns
    PageNavigation: 12,                                                        //2.7 Page Navigation
    ShowRows: 13,                                                              //2.8 Show Rows
    Refresh: 14,                                                               //2.9 Refresh
    AddressBook: 15,                                                           //2.10 Address Book

    //此处除了admin外，如有其他模块功能，各自模块需各自处理
    Homepage: 16,                                                              //3 Homepage
    LoginNameDisplay: 17,                                                      //3.1 Login Name Display
    Simulate: 18,                                                              //3.2 Simulate
    CustomGroups: 19,                                                          //3.3 Custom Groups
    Announcements: 20,                                                         //3.4 Announcements
    AnnouncementActivity: 21,                                                  //3.4.1 Announcement Activity
    AnnouncementManagement: 22,                                                //3.4.2 Announcement Management
    CreatingAnnouncement: 23,                                                  //3.4.2.1	Creating an Announcement
    AnnouncementTemplateBank: 24,                                              //3.4.3 Announcement Template Bank
    CreatingAnnouncementTemplate: 25,                                          //3.4.3.1	Creating an Announcement Template
    ManagingAnnouncementTemplates: 26,                                         //3.4.3.2	Managing Announcement Templates
    MyInvigilationDuties: 27,                                                  //3.5 My Invigilation Duties
    Calendar: 28,                                                              //3.6 Calendar
    MyFavouriteLinks: 29,                                                      //3.7 My Favourite Links
    SubmitRequest: 30,                                                         //3.8 Submit Request
    MyTasks: 31,                                                               //3.9 My Tasks
    ApprovalTasks: 32,                                                         //3.9.1 Approval Tasks
    IndicateAvailability: 33,                                                  //3.9.2 Indicate Availability
    IndicateUnavailability: 34,                                                //3.9.3 Indicate Unavailability
    AcknowledgeOfferOfEngagement: 35,                                          //3.9.4 Acknowledge Offer of Engagement
    InvigilationDutySwopRequests: 36,                                          //3.9.5 Invigilation Duty Swop Requests
    PrintingTasks: 37,                                                         //3.9.6 Printing Tasks
    AssignInvigilator: 38,                                                     //3.9.7 Assign Invigilator
    AssignVenueAndSeatNumber: 39,                                              //3.9.8 Assign Venue and Seat Number
    AssignedTasks: 40,                                                         //3.9.9 Assigned Tasks
    ArchivalAndDisposalRequests: 41,                                           //3.9.10 Archival and Disposal Requests
    MyRequests: 42,                                                            //3.10 My Requests

    //4 Scheduling
    Scheduling: 43,                                                            //4 Scheduling
    ViewAssessmentScheduleConsolidated: 44,                                    //4.1 View Assessment Schedule (Consolidated)
    ViewAssessmentScheduleByStudent: 45,                                       //4.2 View Assessment Schedule (By Student)
    SwopInvigilationDuties: 46,                                                //4.3 Swop Invigilation Duties
    ModuleSetup: 47,                                                           //4.4 Module Setup
    AssessmentInstanceCreation: 48,                                            //4.5 Assessment Instance Creation
    AssessmentInformationCollation: 49,                                        //4.6 Assessment Information Collation
    ModuleSelection: 50,                                                       //4.6.1 Module Selection
    TimelineConfigurationAndEmailNotification: 51,                             //4.6.2 Timeline Configuration and Email Notification
    SchoolDeadlineSetup: 52,                                                   //4.6.3 School Deadline Setup
    InformationCollationAndApproval: 53,                                       //4.6.4 Information Collation and Approval
    AssessmentScheduling: 54,                                                  //4.7 Assessment Scheduling
    ScheduleSetupForAssessment: 55,                                            //4.7.1 Schedule Setup for Assessment
    PaperOnlineOnlineAndPaper: 56,                                             //4.7.1.1	Paper,Online,Online and Paper
    PracticalAssessmentAndGradedAssignment: 57,                                //4.7.1.2	Practical Assessment and Graded Assignment
    AssignVenueAndSeatNumber2: 58,                                              //4.7.2 Assign Venue and Seat Number
    MainAssessment: 59,                                                        //4.7.2.1	Main Assessment
    PaperOnlineOnlineAndPaper2: 60,                                             //4.7.2.1.1 Paper,Online,Online and Paper
    PracticalAssessment: 61,                                                   //4.7.2.1.2 Practical Assessment
    GradedAssignment: 62,                                                      //4.7.2.1.3 Graded Assignment
    MakeupAssessment: 63,                                                      //4.7.2.2	Make-up Assessment
    PaperOnlineOnlineAndPaper3: 64,                                             //4.7.2.2.1 Paper,Online,Online and Paper
    PracticalAssessment3: 65,                                                   //4.7.2.2.2 Practical Assessment
    BasicInformation: 66,                                                      //4.7.3 Basic Information
    AssessmentInformation: 67,                                                 //4.7.4 Assessment Information
    MockAssessmentSetup: 68,                                                   //4.7.5 Mock Assessment Setup
    PaperOnlineOnlineAndPaper4: 69,                                             //4.7.5.1	Paper,Online,Online and Paper
    PracticalAssessment4: 70,                                                   //4.7.5.2 Practical Assessment
    GradedAssignment3: 71,                                                      //4.7.5.3 Graded Assignment
    AllMockAssessmentsinSchedulingStage: 72,                                   //4.7.6 All Mock Assessments in Scheduling Stage
    InvigilatorAssignment: 73,                                                 //4.8 Invigilator Assignment
    ConfigurationAndAssessmentInstanceDetails: 74,                             //4.8.1 Configuration and Assessment Instance Details
    TimelineSetup: 75,                                                         //4.8.2 Timeline Setup
    FullTimeStaffToBeInvited: 76,                                              //4.8.3 Full-Time Staff to Be Invited
    IndicateNumberOfInvigilatorsRequired: 77,                                  //4.8.4 Indicate Number of Invigilators Required
    InvigilatorAssignment2: 78,                                                 //4.8.5 Invigilator Assignment
    AssociateLecturerInvigilatorAssignment: 79,                                //4.8.5.1 Associate Lecturer Invigilator Assignment
    FullTimeStaffInvigilatorAssignment: 80,                                    //4.8.5.2 Full-Time Staff Invigilator Assignment
    AssignChiefInvigilator: 81,                                                //4.8.5.3 Assign Chief Invigilator
    SeatNumberConfigurationForInvigilators: 82,                                //4.8.6 Seat Number Configuration for Invigilators
    NumberOfRovingAndStandbyInvigilators: 83,                                  //4.8.7 Number of Roving and Standby Invigilators
    AssignAmendInvigilatorAssignment: 84,                                      //4.8.8 Assign/Amend Invigilator Assignment
    SeatRangeAssignmentForInvigilator: 85,                                     //4.8.9 Seat Range Assignment for Invigilator
    SchoolLevelConfiguration: 86,                                              //4.8.10 School Level Configuration
    ModuleLevelConfiguration: 87,                                              //4.8.11 Module Level Configuration
    AssociateLecturerInvitation: 88,                                           //4.8.12 Associate Lecturer Invitation
    AvailabilityOfFullTimeStaff: 89,                                           //4.8.13 Availability of Full-Time Staff
    RovingAndStandbyInvigilatorNumbers: 90,                                    //4.8.14 Roving and Standby Invigilator Numbers
    AmendAndConfirmInvigilatorForFullTimeStaff: 91,                            //4.8.15 Amend and Confirm Invigilator for Full-Time Staff
    AssignAmendInvigilatorAssignmentForPracticalAssessment: 92,                //4.8.16 Assign/Amend Invigilator Assignment for Practical Assessment
    ClusterManagement: 93,                                                     //4.8.16.1 Cluster Management
    InvigilatorAssignmentForMockAssessment: 94,                                //4.8.17 Invigilator Assignment for Mock Assessment
    AllMockAssessmentsinInvigilatorAssignmentStage: 95,                        //4.8.18 All Mock Assessments in Invigilator Assignment Stage
    SchedulingSettings: 96,                                                    //4.9 Scheduling Settings
    AssessmentNameModeAndDurationSettings: 97,                                 //4.9.1 Assessment Name, Mode, and Duration Settings
    FieldsAndAssessmentNotesSettings: 98,                                      //4.9.2 Fields and Assessment Notes Settings
    DisplayFieldsConfiguration: 99,                                            //4.9.2.1	Display Fields Configuration
    DisplayFieldsToStudents: 100,                                               //4.9.2.2	Display Fields to Students
    AssessmentNotes: 101,                                                       //4.9.2.3	Assessment Notes
    SpecialInstructionsForStudents: 102,                                        //4.9.3 Special Instructions for Students
    SessionSettingForStudents: 103,                                             //4.9.4 Session Setting for Students
    ModuleManagerPaperCrafterRightsSettings: 104,                               //4.9.5 Module Manager Paper Crafter Rights Settings
    AssessmentCutoffDateSettings: 105,                                          //4.9.6 Assessment Cut-off Date Settings
    SA20ScheduleSettings: 106,                                                  //4.9.7 SA2.0 Schedule Settings
    InvigilatorInstructionsConfiguration: 107,                                  //4.9.8 Invigilator Instructions Configuration
    VenueRequirementsConfiguration: 108,                                        //4.9.9 Venue Requirements Configuration
    InvigilatorComments: 109,                                                   //4.9.10 Invigilator Comments
    SessionSettingsForAssessmentAndStaff: 110,                                  //4.9.11 Session Settings for Assessment and Staff
    TermsAndConditionsForIndicatingAvailability: 111,                           //4.9.12 Terms and Conditions for Indicating Availability
    OfferOfEngagementSettings: 112,                                             //4.9.13 Offer of Engagement Settings
    InvigilatorAllocationRuleSettings: 113,                                     //4.9.14 Invigilator Allocation Rule Settings
    DutySwopSettings: 114,                                                      //4.9.15 Duty Swop Settings
    ClusterSettings: 115,                                                       //4.9.16 Cluster Settings
    InvigilatorSeatNumberArrangement: 116,                                      //4.9.17 Invigilator Seat Number Arrangement
    AssociateLecturerValidAssignmentPeriod: 117,                                //4.9.18 Associate Lecturer Valid Assignment Period

    //5 Authoring
    Authoring: 118,                                                             //5 Authoring
    AssignmentInstructions: 119,                                                //5.1 Assignment Instructions
    TableOfSpecificationsTOS: 120,                                              //5.2 Table of Specifications (TOS)
    AssessmentQuestionContainer: 121,                                           //5.3 Assessment Question Container
    AssessmentDocument: 122,                                                    //5.4 Assessment Document
    Deliverable: 123,                                                           //5.5 Deliverable
    EssayAndReflectionJournal: 124,                                             //5.5.1 Essay and Reflection Journal
    FileSubmission: 125,                                                        //5.5.2 File Submission
    PeerEvaluationAndSelfEvaluation: 126,                                       //5.5.3 Peer Evaluation and Self Evaluation
    OnlineAssessmentAndOfflineAssessment: 127,                                  //5.5.4 Online Assessment and Offline Assessment
    Rubrics: 128,                                                               //5.6 Rubrics
    CreateRubrics: 129,                                                         //5.6.1 Create Rubrics
    CreateRubric: 130,                                                          //5.6.1.1 Create Rubric
    SubmitForApproval: 131,                                                     //5.6.2 Submit for Approval
    HardcopyConfiguration: 132,                                                 //5.7 Hardcopy Configuration
    AssessmentWeighting: 133,                                                   //5.8 Assessment Weighting
    AssignStudents: 134,                                                        //5.9 Assign Students
    AssignRole: 135,                                                            //5.10 Assign Role
    QuestionBank: 136,                                                          //5.11 Question Bank
    ReferenceMaterialBank: 137,                                                 //5.12 Reference Material Bank
    ManageDependencyProfiles: 138,                                              //5.13 Manage Dependency Profiles
    ManageTopics: 139,                                                          //5.14 Manage Topics
    OnlineAssessmentSettings: 140,                                              //5.15 Online Assessment Settings
    CommonSettings: 141,                                                        //5.16 Common Settings
    ViewRubricsSettings: 142,                                                   //5.17 View Rubrics Settings
    AuthoringSettings: 143,                                                     //5.18 Authoring Settings
    OnlineAssessmentSettings2: 144,                                              //5.18.1 Online Assessment Settings
    AuthoringTimelineTOSCommonConfigurations: 145,                              //5.18.2 Authoring Timeline/TOS/Common Configurations
    ManageAuthoringTemplates: 146,                                              //5.18.3 Manage Authoring Templates
    SampleAssessment: 147,                                                      //5.19 Sample Assessment
    ManageQuestionsForSampleAssessment: 148,                                    //5.19.1 Manage Questions for Sample Assessment
    CreateQuestion: 149,                                                        //5.19.1.1 Create Question
    ManageSampleAssessmentPapers: 150,                                          //5.19.2 Manage Sample Assessment Papers
    CreatePaper: 151,                                                           //5.19.2.1 Create Paper

    //6 Printing and Tracking
    PrintingAndTracking: 152,                                                   //6 Printing and Tracking
    PrintingAndPackingRequirements: 153,                                        //6.1 Printing and Packing Requirements
    VerifySampleCopy: 154,                                                      //6.2 Verify Sample Copy
    PrintingProcess: 155,                                                       //6.3 Printing Process
    Printing: 156,                                                              //6.3.1 Printing
    Packing: 157,                                                               //6.3.2 Packing
    Checking: 158,                                                              //6.3.3 Checking
    Sealing: 159,                                                               //6.3.4 Sealing
    CollectionProcess: 160,                                                     //6.4 Collection Process
    PrintingAndTrackingCommonSettings: 161,                                     //6.5 Printing and Tracking Common Settings
    ConfigurePrintingAndPackingRequirements: 162,                               //6.5.1 Configure Printing and Packing Requirements
    ConfigureEnvelopeCalculation: 163,                                          //6.5.2 Configure Envelope Calculation
    //none
    ConfigurePrintingTimeline: 164,                                             //6.5.3 Configure Printing Timeline
    CollectionTimeline: 165,                                                    //6.5.3.1 Collection Timeline
    VerifySampleCopyTimeslots: 166,                                             //6.5.3.2 Verify Sample Copy Timeslots
    SelectTimeslotsForMyModules: 167,                                           //6.5.3.3 Select Timeslots for My Modules
    RovingEnvelopeTimeline: 168,                                                //6.5.3.4 Roving Envelope Timeline
    DeadlineConfigurationForPrintingAndPackingRequirements: 169,                //6.5.3.5 Deadline Configuration for Printing and Packing Requirements
    AssignDelegatedStaff: 170,                                                  //6.5.3.6 Assign Delegated Staff
    ConfigurePrintingStage: 171,                                                //6.5.4 Configure Printing Stage
    ManageStageTemplates: 172,                                                  //6.5.5 Manage Stage Templates
    ConfigureNumberOfEnvelopesToPerformCheck: 173,                              //6.5.6 Configure Number of Envelopes to Perform Check
    ArchivalAndDisposalTimeline: 174,                                           //6.5.7 Archival and Disposal Timeline
    ArchivalAndDisposalStage: 175,                                              //6.5.8 Archival and Disposal Stage
    ArchivalAndDisposalStage2: 176,                                              //6.5.8.1 Archival and Disposal Stage
    IssueBags: 177,                                                             //6.5.8.2 Issue Bags
    PackDocumentsAndSubmitDisposalRequest: 178,                                 //6.5.8.3 Pack Documents and Submit Disposal Request
    OnsiteDisposalTimeConfiguration: 179,                                       //6.5.8.4 On-site Disposal Time Configuration
    HandOverPackedBags: 180,                                                    //6.5.8.5 Hand Over Packed Bags
    ActualOnsiteDisposal: 181,                                                  //6.5.8.6 Actual On-site Disposal
    ManageOutsourcedPrintings: 182,                                             //6.5.9 Manage Outsourced Printings

    //7 Conduct of Assessment
    ShreddedPages: 183,                                                         //6.5.10 Shredded Pages
    ConductOfAssessment: 184,                                                   //7 Conduct of Assessment
    AllAssessments: 185,                                                        //7.1 All Assessments
    ProvideAcknowledgement: 186,                                                //7.1.1 Provide Acknowledgement
    StartAssessment: 187,                                                       //7.1.2 Start Assessment
    MarkAttendance: 188,                                                        //7.1.3 Mark Attendance
    ViewInvigilatorInstructions: 189,                                           //7.1.4 View Invigilator Instructions
    SubmitInvigilationReport: 190,                                              //7.1.5 Submit Invigilation Report
    UnlockInvigilationReport: 191,                                              //7.1.6 Unlock Invigilation Report
    UnauthorisedURLApplicationAccessList: 192,                                  //7.1.7 Unauthorised URL/Application Access List
    ExportEditInvigilationReport: 193,                                          //7.1.8 Export/Edit Invigilation Report
    DownloadAcknowledgementForm1ReceiptOfSealedEnvelopesbeforeStartOfAssessment: 194,          //7.1.9 Download Acknowledgement Form 1 - Receipt of Sealed Envelopes before Start of Assessment
    DownloadAcknowledgementForm2ReceiptOfReturnOfScripts: 195,                  //7.1.10 Download Acknowledgement Form 2 - Receipt of Return of Scripts
    ConfigureStage: 196,                                                        //7.1.11 Configure Stage
    AssignTeam: 197,                                                            //7.1.12 Assign Team
    ReleaseAssignmentInstructions: 198,                                         //7.1.13 Release Assignment Instructions
    ManageSubmission: 199,                                                      //7.1.14 Manage Submission
    ReleaseDeliverable: 200,                                                    //7.1.15 Release Deliverable
    OpenDeliverable: 201,                                                       //7.1.16 Open Deliverable
    ViewEnvelopeAcknowledgementAndProvideAcknowledgementOnBehalf: 202,          //7.1.17 View Envelope Acknowledgement and Provide Acknowledgement on Behalf
    ViewReportSubmissionAndSubmitOnBehalf: 203,                                 //7.1.18 View Report Submission and Submit on Behalf
    ConfigureAssessmentVisibilityForStudents: 204,                              //7.2 Configure Assessment Visibility for Students
    ConfigureAddendum: 205,                                                     //7.3 Configure Addendum
    InvigilatorInstructionsConfiguration2: 206,                                  //7.4 Invigilator Instructions Configuration
    EnableDisableNotificationOfDeliverableSubmission: 207,                      //7.5 Enable/Disable Notification of Deliverable Submission
    ConfigureGraceBufferPeriod: 208,                                            //7.6 Configure Grace/Buffer Period

    //8 Marking and Processing
    ConfigureReminderAndFrequencyBeforeDeadline: 209,                           //7.7 Configure Reminder and Frequency Before Deadline
    MarkingAndProcessing: 210,                                                  //8 Marking and Processing
    AssessmentMarkingSettings: 211,                                             //8.1 Assessment Marking Settings
    AssignMarkerAndChecker: 212,                                                //8.2 Assign Marker and Checker
    UploadedScriptsForOnlineMarking: 213,                                       //8.3 Uploaded Scripts for Online Marking
    QualityAssuranceForMarkingBenchmarking: 214,                                //8.4 Quality Assurance for Marking (Benchmarking)
    QualityAssuranceForMarkingSeeding: 215,                                     //8.5 Quality Assurance for Marking (Seeding)
    AssessmentMarking: 216,                                                     //8.6 Assessment Marking
    MarkQuestion: 217,                                                          //8.6.1 Mark Question
    MarkStudent: 218,                                                           //8.6.2 Mark Student
    MarkDeliverable: 219,                                                       //8.6.3 Mark Deliverable
    MarkRubrics: 220,                                                           //8.6.4 Mark Rubrics
    AssessmentResultsProcessing: 221,                                           //8.7 Assessment Results Processing
    MarkingSettings: 222,                                                       //8.8 Marking Settings
    GlobalMarkingSettings: 223,                                                 //8.8.1 Global Marking Settings
    MarkingTimelineConfiguration: 224,                                          //8.8.2 Marking Timeline Configuration
    MarkingTimelineConfigurationForMock: 225,                                   //8.8.3 Marking Timeline Configuration for Mock

    //9 Students with Special Arrangements
    ScoreToGradeMapping: 226,                                                   //8.8.4 Score to Grade Mapping
    StudentswithSpecialArrangements: 227,                                       //9 Students with Special Arrangements
    StudentswithSpecialArrangements2: 228,                                       //9.1 Students with Special Arrangements
    CreateSpecialArrangements: 229,                                             //9.1.1 Create Special Arrangements

    //10 Reports
    RequirementSettings: 230,                                                   //9.2 Requirement Settings
    Reports: 231,                                                               //10 Reports
    AssessmentScheduling2: 232,                                                  //10.1 Assessment Scheduling
    AssessmentInformationSubmissionProgressReport: 233,                         //10.1.1 Assessment Information Submission Progress Report
    AssessmentInformationReport: 234,                                           //10.1.2 Assessment Information Report
    AssessmentSchedulingSummaryReport: 235,                                     //10.1.3 Assessment Scheduling Summary Report
    AssessmentSchedulingDetailedReport: 236,                                    //10.1.4 Assessment Scheduling Detailed Report
    VenueAvailability: 237,                                                     //10.1.5 Venue Availability
    ConsolidatedAssessmentScheduleReport: 238,                                  //10.1.6 Consolidated Assessment Schedule Report
    AssessmentInvigilation: 239,                                                //10.2 Assessment Invigilation
    AssociateLecturerAvailabilityReport: 240,                                   //10.2.1 Associate Lecturer Availability Report
    FullTimeStaffAvailabilityReport: 241,                                       //10.2.2 Full-Time Staff Availability Report
    AssociateLecturerInvigilationAllocationStatisticsReport: 242,               //10.2.3 Associate Lecturer Invigilation Allocation Statistics Report
    OfferOfEngagementStatusReport: 243,                                         //10.2.4 Offer of Engagement Status Report
    InvigilationDutyAssignmentReport: 244,                                      //10.2.5 Invigilation Duty Assignment Report
    AssociateLecturerDutyCompletionReport: 245,                                 //10.2.6 Associate Lecturer Duty Completion Report
    InvigilationAllocationStatistics: 246,                                      //10.2.7 Invigilation Allocation Statistics
    StaffDistributionForInvigilationReport: 247,                                //10.2.8 Staff Distribution for Invigilation Report
    StaffAssignmentForInvigilation: 248,                                        //10.2.9 Staff Assignment for Invigilation
    InvigilatorAssignmentStatisticsPerModule: 249,                              //10.2.10 Invigilator Assignment Statistics per Module
    AssessmentAuthoring: 250,                                                   //10.3 Assessment Authoring
    AssessmentAuthoringProgressDetails: 251,                                    //10.3.1 Assessment Authoring Progress Details
    AssessmentDocumentApprovedProgress: 252,                                    //10.3.2 Assessment Document Approved Progress
    AssessmentPrinting: 253,                                                    //10.4 Assessment Printing
    PrintingProgressSummaryReport: 254,                                         //10.4.1 Printing Progress Summary Report
    PrintingAndPackingReport: 255,                                              //10.4.2 Printing and Packing Report
    OverallPrintingDataReport: 256,                                             //10.4.3 Overall Printing Data Report
    CheckingReport: 257,                                                        //10.4.4 Checking Report
    SealingReport: 258,                                                         //10.4.5 Sealing Report
    CollectionReport: 259,                                                      //10.4.6 Collection Report
    ArchivalAndDisposalReport: 260,                                             //10.4.7 Archival and Disposal Report
    ShreddedReport: 261,                                                        //10.4.8 Shredded Report
    AssessmentTaking: 262,                                                      //10.5 Assessment Taking
    AssessmentProgressLiveReport: 263,                                          //10.5.1 Assessment Progress Live Report
    PostAssessmentSummaryReport: 264,                                           //10.5.2 Post Assessment Summary Report
    PostAssessmentSummaryStudentDetailsReport: 265,                             //10.5.3 Post Assessment Summary - Student Details Report
    InvigilationReport: 266,                                                    //10.5.4 Invigilation Report
    InvigilationReportSubmissionStatus: 267,                                    //10.5.5 Invigilation Report Submission Status
    MakeupAssessmentEligibilityReport: 268,                                     //10.5.6 Make-up Assessment Eligibility Report
    SampleAssessmentReport: 269,                                                //10.5.7 Sample Assessment Report
    SampleAssessmentReportDetails: 270,                                         //10.5.8 Sample Assessment Report Details
    StudentLaptopReadinessReport: 271,                                          //10.5.9 Student Laptop Readiness Report
    InvigilationReportSubmissionAndInterfacingSummaryReport: 272,               //10.5.10 Invigilation Report Submission and Interfacing Summary Report
    EnvelopeHandoverDetailsReport: 273,                                         //10.5.11 Envelope Handover Details Report
    AssessmentMarking3: 274,                                                     //10.6 Assessment Marking
    GradePublishingReport: 275,                                                 //10.6.1 Grade Publishing Report
    MarkingProgressOverallSummary: 276,                                         //10.6.2 Marking Progress - Overall Summary 
    MarkingProgressByQuestion: 277,                                             //10.6.3 Marking Progress - By Question
    MarkingProgressByStudent: 278,                                              //10.6.4 Marking Progress - By Student
    ScannedPaperScriptsForOnlineMarking: 279,                                   //10.6.5 Scanned Paper Scripts for Online Marking
    ScannedPaperScriptsForOnlineMarkingPerStudent: 280,                         //10.6.6 Scanned Paper Scripts for Online Marking – Per Student
    ScannedPaperScriptsForOnlineMarkingBackupPaper: 281,                        //10.6.7 Scanned Paper Scripts for Online Marking – Backup Paper
    ScannedPaperScriptsForOnlineMarkingBackupPaperPerStudent: 282,              //10.6.8 Scanned Paper Scripts for Online Marking – Backup Paper Per Student
    GradingDetailsOverallSummary: 283,                                          //10.6.9 Grading Details – Overall Summary
    GradingDetailsBySection: 284,                                               //10.6.10 Grading Details – By Section
    AssessmentLevelGradeStatistics: 285,                                        //10.6.11 Assessment Level Grade Statistics
    QuestionLevelSummaryStatistics: 286,                                        //10.6.12 Question Level Summary Statistics
    QualityAssuranceForMarkingBenchmarkingReport: 287,                          //10.6.13 [Quality Assurance for Marking] Benchmarking Report
    QualityAssuranceForMarkingSeedingReport: 288,                               //10.6.14 [Quality Assurance for Marking] Seeding Report
    QualityAssuranceForMarkingSeedingReportByMarker: 289,                       //10.6.15 [Quality Assurance for Marking] Seeding Report – By Marker
    QualityAssuranceForMarkingSeedingReportByResponse: 290,                     //10.6.16 [Quality Assurance for Marking] Seeding Report – By Response
    CutoffDeviationReport: 291,                                                 //10.6.17 Cut-off Deviation Report
    SpecialNeedStudents: 292,                                                   //10.7 Special Need Students
    StudentswithApprovedSpecialAssessmentArrangements: 293,                     //10.7.1 Students with Approved Special Assessment Arrangements
    ApprovedSpecialArrangementForAssessment: 294,                               //10.7.2 Approved Special Arrangement for Assessment
    Others: 295,                                                                //10.8 Others
    StudentEnrolment: 296,                                                      //10.8.1 Student Enrolment

    //11 Archives
    Archives: 297,                                                              //11 Archives
    GlobalFreezeArchivalDuration: 298,                                          //11.1 Global Freeze / Archival Duration
    GlobalFreezeTimeConfiguration: 299,                                         //11.2 Global Freeze Time Configuration
    FreezeAndArchivalScheduleConfiguration: 300,                                //11.3 Freeze and Archival Schedule Configuration
    ConfiguringFreezeAndArchivalSchedulesforAssessment: 301,                    //11.3.1 Configuring Freeze and Archival Schedules for an Assessment 
    ExportingAndImportingFreezeAndArchivalSchedules: 302,                       //11.3.2 Exporting and Importing Freeze and Archival Schedules
    ViewingImportHistory: 303,                                                  //11.3.3 Viewing Import History
    FreezingOrUnfreezingAssessment: 304,                                        //11.4 Freezing or Unfreezing Assessment
    RequestToViewArchivedAssessment: 305,                                       //11.5 Request to View Archived Assessment
    StartingRequest: 306                                                       //11.6 Starting Request
};
