/*© 2023, AvePoint, Inc. All rights reserved.*/
function Preview() {

    for (var key in window.PreviewQuestionI18NMap) {
        __DefaultI18NMap__.put("AveUIGuiCommon" + key, PreviewQuestionI18NMap[key]);
    }
    //var previewType = {
    //    question: 1,
    //    answer: 2
    //}
    var questionProps = null;
    var answerProps = null;

    //if (window.type == previewType.question) {
    //    questionProps = {
    //        previewData: window.markingQuestion,
    //        disabled: true,
    //        showMarks: false,
    //        showCorrectAnswer: true,
    //        showResponseOnly: true,
    //        showPaperModeQuestion: true
    //    };
    //}

    if (window.markingIsPaperMode.toLowerCase() == "true") {
        $(".response_twomode_title").css("display", "none");
        var temp1 = $.extend(true, {}, window.markingQuestion);
        temp1.id = CommonUtil.generatGuid();
        questionProps = {
            previewData: temp1,
            showQuestion: true,
            disabled: true,
            showMarks: false,
            showCorrectAnswer: true,
            showResponseOnly: false,
            showPaperModeQuestion: true
        };
        if (questionProps != null) {
            ReactDOM.render(
                React.createElement(
                    $g.PreviewQuestion,
                    questionProps
                ),
                document.getElementById('preview'))
        }
		if(window.markingPaperAnswer!="data:image/png;base64,")
		{
			$("#paperAnswerImg").attr("src", window.markingPaperAnswer);
		}
        
    } else {
        $("#paperAnswer").css("display", "none");
        if (window.markingTwoAnswerUsed.toLowerCase() == "true") {
            var temp1 = $.extend(true, {}, window.markingQuestion);
            temp1.id = CommonUtil.generatGuid();
            if (window.questionType == "6") {
                temp1.base64Url = window.markingImageLabelingBase64;
            } 
            questionProps = {
                previewData: temp1,
                showQuestion: true,
                disabled: true,
                showMarks: false,
                showCorrectAnswer: true,
                showResponseOnly: false,
                showPaperModeQuestion: true
            };
            var temp2 = $.extend(true, {}, window.markingQuestion);
            temp2.id = CommonUtil.generatGuid(); 
            if (window.questionType == "6") {
                temp2.base64Url = window.markingImageLabelingBase64;
            } 
            answerProps = {
                previewData: temp2,
                responseData: window.markingAnswer,
                showQuestion: false,
                disabled: true,
                showMarks: false,
                showCorrectAnswer: false,
                showResponseOnly: true,
                customStyle: { emptyTitleHeight: 0 }
            };

            if (questionProps != null) {
                ReactDOM.render(
                    React.createElement(
                        $g.PreviewQuestion,
                        questionProps
                    ),
                    document.getElementById('preview'))
            }

            var currentBlank = null;
            if (answerProps != null && window.markingAnswer != "") {
                if (window.questionType == "9" && window.separateMarkType == "1") {
                    (questionProps.previewData.blanks || []).forEach(function(item){
						 if (item.id == window.markingAnswer.blankId) {
                            currentBlank = item;
                        }; 	
					});
                }else {
                    ReactDOM.render(
                        React.createElement(
                            $g.PreviewQuestion,
                            answerProps
                        ),
                        document.getElementById('answer'))
                }
            }

            if (currentBlank != null) {
                $("#answer").prev(".response_twomode_title").before('<div><h3 style="font-size: 14px;margin-left: -10px;">' + currentBlank.title + '</h3></div>');
                $("#answer").html('<div style="border:1px solid #bbb ; padding:0 5px; min-height:100px">' + window.markingAnswer.value + '</div>');
            }

            $("#backUpAnswerImg").attr("src", window.markingBackUpAnswer);
        } else {
            $(".response_twomode_title").css("display", "none");
            var temp1 = $.extend(true, {}, window.markingQuestion);
            temp1.id = CommonUtil.generatGuid();
            if (window.questionType == "6") {
                temp1.base64Url = window.markingImageLabelingBase64;
            } 
            questionProps = {
                previewData: temp1,
                showQuestion: true,
                disabled: true,
                showMarks: false,
                showCorrectAnswer: true,
                showResponseOnly: false,
                showPaperModeQuestion: true
            };
            var temp2 = $.extend(true, {}, window.markingQuestion);
            temp2.id = CommonUtil.generatGuid();
            if (window.questionType == "6") {
                temp2.base64Url = window.markingImageLabelingBase64;
            } 
            answerProps = {
                previewData: temp2,
                responseData: window.markingAnswer,
                showQuestion: false,
                disabled: true,
                showMarks: false,
                showCorrectAnswer: false,
                showResponseOnly: true,
                customStyle: { emptyTitleHeight: 0 }
            };

            if (questionProps != null) {
                ReactDOM.render(
                    React.createElement(
                        $g.PreviewQuestion,
                        questionProps
                    ),
                    document.getElementById('preview'))
            }

            if (answerProps != null) {
                if (window.questionType == "9" && window.separateMarkType == "1") {
                    var currentBlank = null;
                    (questionProps.previewData.blanks || []).forEach(function(item){
						if (item.id == window.markingAnswer.blankId) {
                            currentBlank = item;
                        };
					});
                    if (currentBlank != null) {
                        $("#answer").before("<div><h5>" + currentBlank.title + "</h5></div>");
                        $("#answer").html('<div style="border:1px solid #bbb ; padding:0 5px; min-height:100px">' + window.markingAnswer.value + '</div>');
                    }
                } else {
                    ReactDOM.render(
                        React.createElement(
                            $g.PreviewQuestion,
                            answerProps
                        ),
                        document.getElementById('answer'))
                }
            }
        }
    }
}

window.PreviewQuestionI18NMap = {
    GC_PreviewPaper_FullMarks_Entry: "Full Marks: {0}",
    GC_PreviewPaper_FullScore_Entry: "Full Score: {0}",
    GC_PreviewPaper_SectionTotalMarks_Entry: "Maximum Marks for This Section",
    GC_PreviewPaper_SectionTotalScore_Entry: "Maximum Score for This Section",
    GC_PreviewPaper_SectionEnd_Entry: "END OF {0}",
    GC_PreviewQuestion_Question_Entry: "Question {0}",
    GC_PreviewQuestion_Mark_Entry: "({0} mark)",
    GC_PreviewQuestion_Marks_Entry: "({0} marks)",
    GC_PreviewQuestion_Score_Entry: "(Score: {0})",
    GC_PreviewQuestion_CorrectOption_Entry: "(Correct Option)",
    GC_PreviewQuestion_AllowRandom_Entry: "(The order of answer options will be randomised for students. If this is not what you expect, please change the 'Randomise Options' setting for this question.)",
    GC_PreviewQuestion_Order_Entry: "Order",
    GC_PreviewQuestion_Answer_Entry: "Answer:",
    GC_PreviewQuestion_MultipleResponse_Entry: "(Multiple Response)",
    GC_PreviewQuestion_Matching_Entry: "(Please link the content on both sides with a line.)",
    GC_PreviewQuestion_AnswerOnPapger_Message: "Please answer this question on paper that has been issued to you. If no paper is issued, please contact your invigilator.",
    GC_PreviewQuestion_ShowSeperateOptionMark_Entry: "Show Separate Option",
    GC_PreviewQuestion_HideSeperateOptionMark_Entry: "Hide Separate Option",
    GC_PreviewQuestion_ShowCombinationReponseMark_Entry: "Show Combinations of Responses",
    GC_PreviewQuestion_HideCombinationReponseMark_Entry: "Hide Combinations of Responses",
    GC_PreviewQuestion_Category_Entry: "Category: {0}",
    GC_PreviewQuestion_Option_Entry: "Option: {0}",
    GC_PreviewQuestion_Options_Entry: "Options: {0}",
    GC_PreviewQuestion_MarksTitle_Entry: "Marks: {0}",
    GC_PreviewQuestion_OtherCombinationsResponses_Entry: "Other Combinations of Responses",
    GC_PreviewQuestion_MaxLine_Entry: "Maximum number of lines: {0}",
    GC_PreviewQuestion_ImageLabelling_Description1_Entry: "Click on relevant point(s) on the image above to provide your response to this question.",
    GC_PreviewQuestion_ImageLabelling_Description1PaperMode_Entry: "Circle on relevant point(s) on the image above to provide your response to this question.",
    GC_PreviewQuestion_ImageLabelling_Description2_Entry: "You may indicate a maximum of {0} point(s).",
    GC_PreviewQuestion_ImageLabelling_Description3_Entry: "Click on an indicated point to delete it if required.",
    GC_PreviewMaterial_ListTitle_Entry: "View Paper Reference Material",
    GC_PreviewQuestionMaterial_ListTitle_Entry: "View Question Reference Material",
    GC_PreviewMaterial_DialogTitle_Entry: "Preview Reference Material",
    GC_PreviewMaterial_Title_Entry: "Title",
    GC_PreviewMaterial_Action_Entry: "Action",
    GC_PreviewMaterial_Type_Entry: "Type",
    GC_PreviewMaterial_Preview_Entry: "Preview",
    GC_PreviewMaterial_Download_Entry: "Download",
    GC_PreviewMaterial_Content_Entry: "Content",
    GC_PreviewMaterial_File_Entry: "File",
    GC_PreviewMaterial_RichTextBox_Entry: "Rich Text Box",
    GC_PreviewMaterial_Close_Entry: "Close",
    GC_PreviewMaterial_NotAllowDownload_Entry: "This file is not allowed to be downloaded.",
    GC_PreviewMaterial_NotAllowPreview_Entry: "This file type is not supported for the preview action.",
    GC_PreviewQuestion_MarkingScheme_Entry: "Marking Scheme"
}

Preview()

